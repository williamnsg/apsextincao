
public class Iniciar {

	public static void main(String[] args) 
	{
		//NovoMenu j = new NovoMenu();
		//j.setVisible(true);
		MenuPrincipal jj = new MenuPrincipal();
		jj.setVisible(true);
	
		}
}
